package com.example.dadosfragmentos;

import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final int[] d4 = {0};

        Button addD4 =(Button) findViewById(R.id.button4);

        addD4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                D4fragment frag1 = new D4fragment();
                ft.add(R.id.LinearLayout1, frag1, Integer.toString(d4[0]));
                d4[0]++;
                ft.commit();

            }
        });

        Button removeD4 =(Button) findViewById(R.id.button5);

        removeD4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                if(fm.findFragmentByTag(Integer.toString(d4[0] -1))!=null){
                    d4[0]--;
                    ft.remove(fm.findFragmentByTag(Integer.toString(d4[0])));
                    ft.commit();
                }else
                    Toast.makeText(getApplicationContext(),"Não há Fragmento para ser removido!",Toast.LENGTH_SHORT).show();


            }
        });




    }
}
